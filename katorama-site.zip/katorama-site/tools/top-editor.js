/* Страница-помощник: вставляете текст из Juniper, получаете готовый data/top.json */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var json = "";

  $("build").addEventListener("click", function () {
    var top = window.TopParser.buildTop($("points").value, $("voice").value);
    json = JSON.stringify(top, null, 2) + "\n";
    $("out").value = json;
    $("info").textContent = "Очки: " + top.points.length + " участн., войс: " + top.voice.length + " участн.";
  });
  $("copy").addEventListener("click", function () {
    if (!json) return;
    if (navigator.clipboard) navigator.clipboard.writeText(json).then(function () { $("info").textContent = "Скопировано."; });
  });
  $("download").addEventListener("click", function () {
    if (!json) return;
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([json], { type: "application/json" }));
    a.download = "top.json";
    a.click();
    URL.revokeObjectURL(a.href);
  });
})();
