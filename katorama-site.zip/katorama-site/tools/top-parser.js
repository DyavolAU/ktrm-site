/* Разбор вывода команды Juniper (leaders / рейтинг) в данные для data/top.json. Работает в браузере и в Node. */
(function (root) {
  "use strict";

  /* Шрифтовые «красивые» буквы (𝓭𝓸𝓫𝓫𝓲) превращаем в обычные, остальное чистим */
  function plainFancy(str) {
    var out = "";
    for (var ch of str) {
      var cp = ch.codePointAt(0);
      out += cp >= 0x1D400 && cp <= 0x1D7FF ? ch.normalize("NFKC") : ch;
    }
    return out;
  }

  function cleanName(raw) {
    var s = plainFancy(String(raw))
      .replace(/\p{Lm}/gu, " ")
      .replace(/[^\p{L}\p{N} ._\/-]/gu, " ")
      .replace(/\s+/g, " ").trim();
    return s.slice(0, 48);
  }

  function toSeconds(str) {
    var p = String(str).split(":").map(Number);
    if (p.some(isNaN)) return 0;
    return p.reduce(function (a, x) { return a * 60 + x; }, 0);
  }

  /* Возвращает [{rank, name, level, xp, seconds}] в порядке текста */
  function parseLeaders(text) {
    var lines = String(text).split(/\r?\n/), out = [], cur = null;
    lines.forEach(function (line) {
      var head = line.match(/^\s*#\s*(\d+)\.\s*@?(.*?)\s*(?:\(([^()]*)\))?\s*$/);
      if (head) {
        cur = { rank: Number(head[1]), name: cleanName(head[2]), level: 0, xp: 0, seconds: 0 };
        out.push(cur);
        return;
      }
      var st = line.match(/Уровень:\s*(\d+)\s*\|\s*Опыт:\s*(\d+)\s*\|\s*([\d:]+)/);
      if (st && cur) {
        cur.level = Number(st[1]); cur.xp = Number(st[2]); cur.seconds = toSeconds(st[3]);
        cur = null;
      }
    });
    return out.filter(function (e) { return e.name; });
  }

  function buildTop(pointsText, voiceText, now) {
    var pts = parseLeaders(pointsText), voice = parseLeaders(voiceText);
    return {
      updated: (now || new Date()).toISOString(),
      source: "Juniper",
      points: pts.sort(function (a, b) { return b.xp - a.xp; }).map(function (e) { return { name: e.name, level: e.level, xp: e.xp }; }),
      voice: voice.sort(function (a, b) { return b.seconds - a.seconds; }).map(function (e) { return { name: e.name, seconds: e.seconds }; })
    };
  }

  var api = { parseLeaders: parseLeaders, buildTop: buildTop, cleanName: cleanName };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.TopParser = api;
})(this);
