/* Аркада: мини-игра «Найди предателя» и кошелёк с монетами.
   С Supabase и входом через Discord монеты начисляет сервер (функция earn_coins), иначе работает демо-режим в браузере. */
(function () {
  "use strict";
  var K = window.KTRM, h = K.h;
  var root = K.$("#arcadeRoot");
  if (!root) return;

  var RULES = { seconds: 30, winScore: 15, winCoins: 50, loseCoins: 5, dailyCap: 200, cooldownSec: 25, maxScore: 40 };
  var CREW = ["cyan", "lime", "pink", "yellow", "purple", "orange"];
  var WALLET_KEY = "ktrm-wallet", BEST_KEY = "ktrm-best";

  /* ---------- кошелёк ---------- */
  var coins = 0;
  function today() { return new Date().toISOString().slice(0, 10); }
  function localWallet() {
    var w = K.store.get(WALLET_KEY, null) || {};
    w.coins = Math.max(0, Number(w.coins) || 0);
    if (w.day !== today()) { w.day = today(); w.earned = 0; }
    w.earned = Math.max(0, Number(w.earned) || 0);
    w.last = Number(w.last) || 0;
    return w;
  }
  function synced() { return K.auth.enabled && !!K.auth.user; }

  async function loadBalance() {
    if (synced()) {
      var res = await K.auth.request("GET", "/rest/v1/wallets?select=coins");
      coins = res.ok && Array.isArray(res.data) && res.data[0] ? Number(res.data[0].coins) || 0 : 0;
    } else {
      coins = localWallet().coins;
    }
    drawWallet();
  }

  async function award(score) {
    if (synced()) {
      var res = await K.auth.request("POST", "/rest/v1/rpc/earn_coins", { p_game: "impostor", p_score: score });
      if (res.ok && res.data && typeof res.data.coins === "number") {
        coins = res.data.coins;
        return { earned: Number(res.data.earned) || 0, reason: res.data.reason };
      }
      return { error: true };
    }
    var w = localWallet(), now = Date.now();
    if (now - w.last < RULES.cooldownSec * 1000) return { earned: 0, reason: "cooldown" };
    var reward = score >= RULES.winScore ? RULES.winCoins : RULES.loseCoins;
    reward = Math.min(reward, Math.max(0, RULES.dailyCap - w.earned));
    w.coins += reward; w.earned += reward; w.last = now;
    K.store.set(WALLET_KEY, w);
    coins = w.coins;
    return { earned: reward, reason: score >= RULES.winScore ? "win" : "lose" };
  }

  /* ---------- разметка ---------- */
  var coinsEl = h("strong", { class: "coins-num", text: "0" });
  var modeEl = h("span", { class: "dim" });
  var authBox = h("div", { class: "auth-box" });
  var timeEl = h("b", { text: String(RULES.seconds) });
  var scoreEl = h("b", { text: "0" });
  var bestEl = h("b", { text: String(K.store.get(BEST_KEY, 0)) });
  var startBtn = h("button", { class: "btn", type: "button", text: "Старт" });
  var msg = h("p", { class: "game-msg", role: "status" });
  var arena = h("div", { class: "arena" });
  var holes = [];
  for (var i = 0; i < 9; i++) {
    (function (idx) {
      var hole = h("button", { class: "hole", type: "button", "aria-label": "Нора " + (idx + 1), onclick: function () { hit(idx); } });
      holes.push(hole); arena.appendChild(hole);
    })(i);
  }

  function drawWallet() {
    coinsEl.textContent = K.fmt(coins);
    if (synced()) modeEl.textContent = "Монеты сохраняются в вашем аккаунте Discord.";
    else if (K.auth.enabled) modeEl.textContent = "Пока монеты хранятся только в этом браузере. Войдите через Discord, чтобы они сохранялись в аккаунте.";
    else modeEl.textContent = "Демо-режим: монеты хранятся только в этом браузере и не связаны с магазином.";
  }

  root.appendChild(h("div", { class: "wallet" },
    h("div", { class: "wallet-main" }, h("span", { class: "coin", "aria-hidden": "true" }), coinsEl, h("span", { text: "монет" })),
    modeEl, authBox));
  K.auth.bar(authBox, "arcade");

  root.appendChild(h("div", { class: "game-card" },
    h("h3", { text: "Найди предателя" }),
    h("div", { class: "hud" },
      h("span", {}, "Время ", timeEl), h("span", {}, "Очки ", scoreEl), h("span", {}, "Рекорд ", bestEl), startBtn),
    arena, msg,
    h("p", { class: "dim rules", text: "Нажимайте на красных предателей, пока они не спрятались. Члены экипажа других цветов не трогайте: за них минус очко. Играть можно мышью, пальцем или клавишами 1–9. Победа от " +
      RULES.winScore + " очков: +" + RULES.winCoins + " монет, иначе +" + RULES.loseCoins + "." })));

  /* ---------- игра ---------- */
  var game = null;

  function setHud() { timeEl.textContent = String(game ? game.left : RULES.seconds); scoreEl.textContent = String(game ? game.score : 0); }

  function removeBean(i) {
    var a = game && game.active[i];
    if (!a) return;
    clearTimeout(a.timer);
    if (a.el.parentNode) a.el.parentNode.removeChild(a.el);
    delete game.active[i];
  }

  function spawn() {
    if (!game) return;
    var free = [];
    for (var i = 0; i < 9; i++) if (!game.active[i]) free.push(i);
    if (!free.length) return;
    var idx = free[Math.floor(Math.random() * free.length)];
    var imp = Math.random() < 0.55;
    var el = h("span", { class: "bean " + (imp ? "imp" : "crew"), "data-c": imp ? "red" : CREW[Math.floor(Math.random() * CREW.length)] });
    holes[idx].appendChild(el);
    game.active[idx] = { imp: imp, el: el, timer: setTimeout(function () { removeBean(idx); }, 900) };
  }

  function loop() {
    if (!game) return;
    spawn();
    var elapsed = RULES.seconds - game.left;
    game.spawnTimer = setTimeout(loop, Math.max(420, 760 - elapsed * 10));
  }

  function hit(i) {
    var a = game && game.active[i];
    if (!a) return;
    if (a.imp) game.score++; else game.score = Math.max(0, game.score - 1);
    a.el.classList.add(a.imp ? "hit" : "oops");
    clearTimeout(a.timer);
    a.timer = setTimeout(function () { removeBean(i); }, 160);
    setHud();
  }

  function stop() {
    if (!game) return;
    clearInterval(game.tick); clearTimeout(game.spawnTimer);
    Object.keys(game.active).forEach(function (k) { removeBean(Number(k)); });
    startBtn.disabled = false; startBtn.textContent = "Играть ещё";
  }

  async function finish() {
    var score = game.score;
    stop();
    game = null;
    var best = Number(K.store.get(BEST_KEY, 0)) || 0;
    if (score > best) { K.store.set(BEST_KEY, score); best = score; }
    bestEl.textContent = String(best);
    msg.textContent = "Считаем награду…";
    var r = await award(Math.min(score, RULES.maxScore));
    if (r.error) msg.textContent = "Игра окончена: " + score + " очк. Не удалось начислить монеты, попробуйте позже.";
    else if (r.reason === "cooldown") msg.textContent = "Игра окончена: " + score + " очк. Монеты начисляются не чаще раза в " + RULES.cooldownSec + " секунд.";
    else if (!r.earned) msg.textContent = "Игра окончена: " + score + " очк. Дневной лимит монет (" + RULES.dailyCap + ") достигнут.";
    else msg.textContent = (r.reason === "win" ? "Победа! " : "Не хватило очков до победы (" + RULES.winScore + "). ") + score + " очк., +" + r.earned + " монет.";
    drawWallet();
  }

  function start() {
    if (game) return;
    game = { score: 0, left: RULES.seconds, active: {} };
    msg.textContent = "";
    startBtn.disabled = true; startBtn.textContent = "Идёт игра…";
    setHud();
    game.tick = setInterval(function () {
      game.left--; setHud();
      if (game.left <= 0) finish();
    }, 1000);
    loop();
  }

  function abort() {
    if (!game) return;
    stop(); game = null; setHud();
    startBtn.textContent = "Старт"; msg.textContent = "Игра прервана, награда не начислена.";
  }

  startBtn.addEventListener("click", start);
  document.addEventListener("keydown", function (e) {
    if (!game || !/^[1-9]$/.test(e.key) || K.state.tab !== "arcade") return;
    hit(Number(e.key) - 1);
  });
  document.addEventListener("ktrm:tab", function (e) {
    if (e.detail !== "arcade") abort(); else loadBalance();
  });
  K.auth.onChange(loadBalance);
  loadBalance();
})();
