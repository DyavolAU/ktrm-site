/* Тема оформления: применяется до отрисовки страницы, чтобы не мигало */
(function () {
  var theme = null;
  try { theme = localStorage.getItem("ktrm-theme"); } catch (e) { /* хранилище недоступно */ }
  if (theme !== "light" && theme !== "dark") {
    theme = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  }
  document.documentElement.setAttribute("data-theme", theme);
})();
