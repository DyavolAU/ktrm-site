/* Вход через Discord (Supabase Auth) и запросы к базе. Без настроек Supabase всё остаётся в демо-режиме. */
(function () {
  "use strict";
  var K = window.KTRM, cfg = K.cfg;
  var SESSION_KEY = "ktrm-session";
  var A = K.auth = { enabled: !!(cfg.supabaseUrl && cfg.supabaseAnonKey), user: null, loginError: "" };
  var base = String(cfg.supabaseUrl || "").replace(/\/+$/, "");
  var session = K.store.get(SESSION_KEY, null);
  var listeners = [];

  function emit() { listeners.slice().forEach(function (fn) { try { fn(A.user); } catch (e) { /* ничего */ } }); }
  A.onChange = function (fn) { listeners.push(fn); };

  function userFrom(u) {
    if (!u) return null;
    var m = u.user_metadata || {};
    return {
      id: String(u.id || ""),
      name: K.clean(m.full_name || m.name || m.user_name || "Участник", 64) || "Участник",
      avatar: K.safeAvatar(m.avatar_url),
      discordId: K.clean(m.provider_id || m.sub || "", 32)
    };
  }

  function setSession(s) {
    session = s;
    if (s) K.store.set(SESSION_KEY, s); else K.store.del(SESSION_KEY);
  }

  async function refresh() {
    if (!session || !session.refresh_token) return false;
    try {
      var r = await fetch(base + "/auth/v1/token?grant_type=refresh_token", {
        method: "POST",
        headers: { apikey: cfg.supabaseAnonKey, "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: session.refresh_token })
      });
      if (!r.ok) throw new Error("refresh " + r.status);
      var d = await r.json();
      setSession({
        access_token: d.access_token,
        refresh_token: d.refresh_token,
        expires_at: Math.floor(Date.now() / 1000) + (d.expires_in || 3600),
        user: d.user || session.user
      });
      A.user = userFrom(session.user);
      return true;
    } catch (e) {
      setSession(null); A.user = null; emit();
      return false;
    }
  }

  async function ensure() {
    if (!session) return false;
    if (session.expires_at - 60 > Date.now() / 1000) return true;
    return refresh();
  }

  /* Запрос к Supabase от имени пользователя: {ok, status, data} */
  A.request = async function (method, path, body, extraHeaders) {
    if (!A.enabled) return { ok: false, status: 0, data: null, error: "disabled" };
    if (!(await ensure())) return { ok: false, status: 401, data: null, error: "auth" };
    var headers = { apikey: cfg.supabaseAnonKey, Authorization: "Bearer " + session.access_token };
    Object.keys(extraHeaders || {}).forEach(function (k) { headers[k] = extraHeaders[k]; });
    if (body !== undefined) headers["Content-Type"] = "application/json";
    try {
      var r = await fetch(base + path, { method: method, headers: headers, body: body === undefined ? undefined : JSON.stringify(body) });
      var text = await r.text(), data = null;
      try { data = text ? JSON.parse(text) : null; } catch (e) { /* не JSON */ }
      return { ok: r.ok, status: r.status, data: data };
    } catch (e) {
      return { ok: false, status: 0, data: null, error: "network" };
    }
  };

  /* Возврат со страницы входа Discord: токены приходят в #access_token=... */
  A.handleReturn = function () {
    var h = location.hash || "";
    if (h.indexOf("access_token=") === -1 && h.indexOf("error_description=") === -1) return null;
    var p = new URLSearchParams(h.replace(/^#/, ""));
    var back = null;
    try { back = sessionStorage.getItem("ktrm-after-login"); sessionStorage.removeItem("ktrm-after-login"); } catch (e) { /* ничего */ }
    try { history.replaceState(null, "", location.pathname + location.search); } catch (e) { /* ничего */ }
    if (p.get("access_token") && A.enabled) {
      setSession({
        access_token: p.get("access_token"),
        refresh_token: p.get("refresh_token") || "",
        expires_at: Math.floor(Date.now() / 1000) + (parseInt(p.get("expires_in"), 10) || 3600),
        user: null
      });
    } else {
      A.loginError = K.clean(p.get("error_description") || "Не удалось войти через Discord", 160);
    }
    return back || "chat";
  };

  A.init = async function () {
    if (!A.enabled || !session) { emit(); return; }
    if (session.user) A.user = userFrom(session.user);
    var res = await A.request("GET", "/auth/v1/user");
    if (res.ok && res.data) { session.user = res.data; setSession(session); A.user = userFrom(res.data); }
    else if (res.status === 401) { setSession(null); A.user = null; }
    emit();
  };

  A.login = function (backTab) {
    if (!A.enabled) return;
    try { sessionStorage.setItem("ktrm-after-login", backTab || "chat"); } catch (e) { /* ничего */ }
    location.href = base + "/auth/v1/authorize?provider=discord&redirect_to=" +
      encodeURIComponent(location.origin + location.pathname);
  };

  A.logout = function () { setSession(null); A.user = null; A.loginError = ""; emit(); };

  /* Блок «войти / вы вошли как» для любой вкладки */
  A.bar = function (container, backTab) {
    function draw() {
      K.clear(container);
      if (!A.enabled) {
        container.appendChild(K.h("p", { class: "note", text: "Вход через Discord не настроен (нужен Supabase, см. README). Пока работает демо-режим." }));
        return;
      }
      if (A.user) {
        container.appendChild(K.h("div", { class: "who" },
          A.user.avatar ? K.h("img", { src: A.user.avatar, alt: "", width: "32", height: "32", referrerpolicy: "no-referrer" }) : null,
          K.h("strong", { text: A.user.name }),
          K.h("button", { class: "btn ghost small", type: "button", text: "Выйти", onclick: A.logout })));
      } else {
        container.appendChild(K.h("button", { class: "btn small", type: "button", text: "Войти через Discord", onclick: function () { A.login(backTab); } }));
        if (A.loginError) container.appendChild(K.h("p", { class: "note warn", text: A.loginError }));
      }
    }
    listeners.push(draw);
    draw();
  };
})();
