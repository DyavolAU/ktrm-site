/* Все данные сайта в одном месте: команда, игры, партнёры, запасной рейтинг. */
window.KTRM_DATA = {
  created: "2026-07-06",            /* дата создания сервера (по ID сервера) */
  name: "Katorama | общение",
  language: "Русский",
  description: "Место для общения людей из разных комьюнити. Здесь можно найти общие интересы через общение, игры, войсы и многое другое.",
  inviteUrl: "https://discord.gg/WMn9VsVN7",
  shortInviteUrl: "https://discord.com/invite/katorama",
  descriptionSite: "https://katorama.wwwz.uz/",

  owners: ["Шахта", "Май"],

  /* Команда. change: "up" (повышен) или "down" (понижен) + date (ГГГГ-ММ-ДД).
     Стрелка рядом с ником показывается 10 дней с этой даты и затем пропадает сама. */
  groups: [
    { title: "Tech Admins", color: "cyan", about: "Настраивают сервер, боты и каналы.",
      members: [{ name: "SWAG" }, { name: "Alex" }] },
    { title: "Curators", color: "lime", about: "Следят за общением и помогают новичкам.",
      members: [{ name: "DyavolAU" }, { name: "hikerx" }, { name: "Повелитель" }] },
    { title: "Admin", color: "orange", about: "Администраторы сервера.",
      members: [{ name: "N", change: "up", date: "2026-11-04" }] },
    { title: "Moderator", color: "pink", about: "Следят за порядком на сервере.",
      members: [{ name: "sky", change: "up", date: "2026-10-31" }] },
    { title: "Helper", color: "yellow", about: "Помогают следить за порядком в чатах и голосовых каналах.",
      members: [{ name: "JJ" }, { name: "evil" }, { name: "Samorep" }, { name: "Судья" }, { name: "harakini" },
                { name: "Astolfo", change: "down", date: "2026-11-04" }] },
    { title: "Intern", color: "purple", about: "Стажёры команды.", members: [] },
    { title: "Event Maker", color: "red", about: "Организуют события и игры на сервере.",
      members: [{ name: "DyavolAU" }, { name: "Повелитель" }, { name: "harakini" }] }
  ],

  games: {
    "Among Us":  { color: "red",    text: "Основа сервера. Собираем лобби, играем, спорим на экстренных собраниях и ищем предателя.", top: ["N", "LuT1", "Maloyy"] },
    "PEAK":      { color: "cyan",   text: "Одна из частых игр сервера. Собираем компанию в голосовых каналах.", top: ["ШефSS", "Шахта", "hikerx"] },
    "R.E.P.O.":  { color: "lime",   text: "Одна из частых игр сервера. Собираем компанию в голосовых каналах.", top: ["ШефSS", "Фасолька", "Шахта"] },
    "CS2":       { color: "orange", text: "Одна из частых игр сервера. Собираем компанию в голосовых каналах.", top: ["Повелитель", "LuT1", "Шахта"] },
    "Minecraft": { color: "pink",   text: "Одна из частых игр сервера. Собираем компанию в голосовых каналах.", top: ["sky", "Samorep", "Чюба"] }
  },

  partners: [
    { name: "Чюба", kind: "Telegram-канал", url: "https://t.me/chubaamongus", img: "img/chuba.jpg", color: "red" },
    { name: "Шейди", kind: "Telegram-канал", url: "https://t.me/+5X7SwfUwQYZmZDli", img: "img/shady.jpg", color: "cyan" },
    { name: "Ванлава", kind: "Telegram-канал", url: "https://t.me/amongusaktiv", img: "img/vanlava.jpg", color: "pink" },
    { name: "ВП | Community Among Us", kind: "Telegram-чат", url: "https://t.me/PRchat_Amongus", img: "img/vp.jpg", color: "lime" }
  ],

  /* Запасной рейтинг, если data/top.json недоступен. Актуальные данные лежат в data/top.json */
  topFallback: {
    updated: "2026-10-30T00:00:00Z",
    points: [
      { name: "Шахтёр Lv Ssшаф", level: 100, xp: 1912167 },
      { name: "Май", level: 100, xp: 1902712 },
      { name: "hikerx lv JJ", level: 24, xp: 39260 },
      { name: "dobbi", level: 22, xp: 30509 },
      { name: "злюка чикенганер", level: 21, xp: 27176 },
      { name: "Alex lv nvm", level: 19, xp: 23660 },
      { name: "Повелитель/Артас", level: 17, xp: 17296 },
      { name: "DyavolAU lv Astolfo", level: 17, xp: 17183 },
      { name: "Dedushka", level: 17, xp: 16654 },
      { name: "генерал", level: 16, xp: 15381 }
    ],
    voice: [
      { name: "Шахтёр Lv Ssшаф", seconds: 554424 },
      { name: "Повелитель/Артас", seconds: 449945 },
      { name: "daughter7", seconds: 345513 },
      { name: "DyavolAU lv Astolfo", seconds: 241694 },
      { name: "Chuba", seconds: 199487 },
      { name: "Бигмак", seconds: 196638 },
      { name: "барабиджон нурмухаматов", seconds: 179373 },
      { name: "dobbi", seconds: 167859 },
      { name: "Samorep", seconds: 166818 },
      { name: "sky", seconds: 143101 }
    ]
  }
};
