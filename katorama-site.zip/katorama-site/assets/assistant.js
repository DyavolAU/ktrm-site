/* Помощник во вкладке «О сервере». Лимит: 10 вопросов за 5 часов, вопрос не по теме стоит 2.
   Отвечает по данным сайта (ничего не отправляется на сторону). Счётчик хранится в браузере. */
(function () {
  "use strict";
  var K = window.KTRM, D = K.data, C = K.cfg, h = K.h;
  var root = K.$("#assistant");
  if (!root) return;

  var LIMIT = 10, WINDOW = 5 * 3600 * 1000, KEY = "ktrm-ai";

  /* ---------- лимит вопросов ---------- */
  function quota() {
    var q = K.store.get(KEY, null) || { used: 0, start: 0 };
    q.used = Math.min(LIMIT, Math.max(0, Number(q.used) || 0));
    q.start = Number(q.start) || 0;
    if (q.start && Date.now() - q.start >= WINDOW) q = { used: 0, start: 0 };   /* прошло 5 часов: лимит обновился */
    return q;
  }
  function spend(cost) {
    var q = quota();
    if (!q.start) q.start = Date.now();
    q.used = Math.min(LIMIT, q.used + cost);
    K.store.set(KEY, q);
  }
  function remaining() { return LIMIT - quota().used; }
  function resetIn() { var q = quota(); return q.start ? Math.max(0, q.start + WINDOW - Date.now()) : 0; }
  function limitMessage() {
    return "Лимит закончен, вернитесь через 5 часов. Через " + K.fmtLeft(resetIn()) + " снова будет возможность задать вопросы.";
  }

  /* ---------- база знаний ---------- */
  function norm(s) {
    return String(s).toLowerCase().replace(/ё/g, "е").replace(/[^a-zа-я0-9+ ]/g, " ").replace(/\s+/g, " ").trim();
  }
  function names(arr) { return arr.map(function (m) { return m.name; }).join(", "); }
  function ago(iso) { return Math.max(0, Math.floor(K.daysSince(iso))); }

  function aboutAnswer() {
    return D.name + ": " + D.description + "\nВладельцы: " + D.owners.join(" и ") + ". Игры: " + Object.keys(D.games).join(", ") +
      " и другие.\nВступить: " + D.inviteUrl;
  }
  function ownersAnswer() { return "Владельцы сервера — " + D.owners.join(" и ") + "."; }

  var ROLE_RX = [
    ["Curators", /курат/], ["Moderator", /модер/], ["Helper", /хелпер|helper/], ["Intern", /стаж|intern/], ["Event Maker", /ивент|эвент|event/]
  ];
  function teamAnswer(q) {
    var want = [];
    if (/тех|tech/.test(q)) want.push("Tech Admins");
    else if (/админ|admin/.test(q)) want.push("Tech Admins", "Admin");
    ROLE_RX.forEach(function (r) { if (r[1].test(q)) want.push(r[0]); });
    var lines = [];
    if (!want.length) lines.push("Owner: " + D.owners.join(", ") + ".");
    D.groups.forEach(function (g) {
      if (want.length && want.indexOf(g.title) === -1) return;
      var list = g.members.map(function (m) {
        var recent = m.change && K.daysSince(m.date) < 10;
        return m.name + (recent ? (m.change === "up" ? " (недавно повышен)" : " (недавно понижен)") : "");
      }).join(", ");
      lines.push(g.title + ": " + (list || "пока никого") + ".");
    });
    return lines.join("\n");
  }

  var GAME_RX = {
    "Among Us": /among|амонг|амог/, "PEAK": /peak|(^| )пик( |$)/, "R.E.P.O.": /r ?e ?p ?o|репо/,
    "CS2": /cs ?2|кс ?2|контр/, "Minecraft": /minecraft|майн/
  };
  function gamesAnswer(q) {
    var found = Object.keys(GAME_RX).filter(function (g) { return GAME_RX[g].test(q); });
    if (found.length) {
      return found.map(function (g) {
        return g + ": чаще всех играют " + D.games[g].top.join(", ") + ".";
      }).join("\n");
    }
    return "Главная игра сервера — Among Us. Часто играют также в " + Object.keys(D.games).slice(1).join(", ") +
      " и другие. Во вкладке «Игры» можно посмотреть, кто чаще всех играет в каждую.";
  }

  function joinAnswer() { return "Вступить можно по ссылке: " + D.inviteUrl + " (короткая: " + D.shortInviteUrl + ")."; }
  function membersAnswer() {
    var s = "На сервере около " + K.fmt(K.state.members) + " участников";
    if (K.state.online != null) s += ", сейчас онлайн примерно " + K.fmt(K.state.online);
    return s + ".";
  }
  function createdAnswer() {
    var d = new Date(D.created + "T00:00:00");
    return "Сервер создан " + d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" }) +
      " (дата определена по ID сервера), то есть примерно " + ago(D.created) + " дн. назад.";
  }
  function shopAnswer() {
    return "Магазин находится на отдельном сайте: " + C.shopUrl + "\nНа этом сайте во вкладке «Аркада» можно играть в мини-игру и зарабатывать монеты.";
  }
  function topAnswer() {
    var t = K.state.top || {};
    function best(arr, key, fmt) {
      return (arr || []).slice().sort(function (a, b) { return b[key] - a[key]; }).slice(0, 3).map(function (r, i) { return (i + 1) + ". " + r.name + " (" + fmt(r) + ")"; }).join("; ");
    }
    var s = "Топ по очкам Juniper: " + best(t.points, "xp", function (r) { return "ур. " + r.level; }) +
      ".\nТоп по времени в войсе: " + best(t.voice, "seconds", function (r) { return K.fmtTime(r.seconds); }) + ".";
    if (t.updated) s += "\nДанные обновлены: " + new Date(t.updated).toLocaleString("ru-RU", { dateStyle: "long", timeStyle: "short" }) + ".";
    return s;
  }
  function partnersAnswer() {
    return "Наши партнёры:\n" + D.partners.map(function (p) { return p.name + " — " + p.url; }).join("\n");
  }
  function siteAnswer() {
    return "На сайте есть: аркада с мини-игрой и монетами, общий чат (нужен вход через Discord), светлая и тёмная тема, рейтинг, список участников онлайн, команда и партнёры.";
  }
  function rulesAnswer() {
    return "Язык сервера — русский. Подробных правил в публичной информации о сервере нет, их лучше уточнить у команды на сервере: " + D.inviteUrl;
  }

  var ENTRIES = [
    { keys: [/владел|основател|создател|хозяин|owner/], answer: ownersAnswer },
    { keys: [/админ|admin|модер|курат|хелпер|helper|стаж|intern|ивент|эвент|event|команд|стафф|staff|роль|роли|должност/], answer: teamAnswer },
    { keys: [/игр|among|амонг|амог|peak|(^| )пик( |$)|r ?e ?p ?o|репо|cs ?2|кс ?2|контр|minecraft|майн/], answer: gamesAnswer },
    { keys: [/вступ|зайти|заход|присоедин|приглас|ссылк|попасть|invite/], answer: joinAnswer },
    { keys: [/участник|сколько людей|народ|онлайн|online/], answer: membersAnswer },
    { keys: [/создан|основан|возраст|как давно|когда появил/], answer: createdAnswer },
    { keys: [/магазин|розыгрыш|giveaway|приз|купить|валют|монет|баланс/], answer: shopAnswer },
    { keys: [/топ|рейтинг|лидер|войс|очк|juniper|джунипер|уровен|актив/], answer: topAnswer },
    { keys: [/партн|сотруднич|тгк|телеграм|telegram|канал/], answer: partnersAnswer },
    { keys: [/чат|аккаунт|войти|вход|аркад|миниигр|мини игр|тема|темн|светл|сайт/], answer: siteAnswer },
    { keys: [/язык|правил|нельзя|бан|мут|наказан/], answer: rulesAnswer },
    { keys: [/что такое|что это|кто вы|расскаж|о сервере|про сервер|katorama|катарам|описани|общени/], answer: aboutAnswer }
  ];
  var TOPIC = /сервер|katorama|катарам|дискорд|discord|сайт/;

  function local(text) {
    var q = norm(text), best = null, bestScore = 0;
    ENTRIES.forEach(function (e) {
      var score = e.keys.reduce(function (n, rx) { return n + (rx.test(q) ? 1 : 0); }, 0);
      if (score > bestScore) { best = e; bestScore = score; }
    });
    if (best) return { text: best.answer(q), onTopic: true };
    if (TOPIC.test(q)) {
      return { text: "Точного ответа в данных сайта нет. Спросите команду сервера в Discord: " + D.inviteUrl +
        "\nЯ могу рассказать про владельцев, команду, игры, рейтинг, магазин, партнёров и как вступить.", onTopic: true };
    }
    return { text: "Этот вопрос не по теме сервера Katorama. Я отвечаю про сервер: владельцев, команду, игры, рейтинг, магазин, партнёров и как вступить.", onTopic: false };
  }

  async function answer(text) {
    if (/^https:\/\//.test(C.aiEndpoint || "")) {
      try {
        var r = await fetch(C.aiEndpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: text }) });
        if (r.ok) {
          var j = await r.json();
          if (j && typeof j.answer === "string") {
            return { text: j.answer.replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, "").slice(0, 1200), onTopic: j.onTopic !== false };
          }
        }
      } catch (e) { /* свой сервер недоступен: используем встроенного помощника */ }
    }
    return local(text);
  }

  /* ---------- интерфейс ---------- */
  var log = h("div", { class: "ai-log", role: "log", "aria-live": "polite" });
  var meter = h("p", { class: "ai-meter" });
  var input = h("input", { type: "text", maxlength: "200", placeholder: "Спросите о сервере…", "aria-label": "Вопрос о сервере", autocomplete: "off" });
  var send = h("button", { class: "btn small", type: "button", text: "Спросить" });
  var busy = false;

  function add(role, text, note) {
    var body = role === "bot" ? K.linkify(text) : text;
    var msg = h("div", { class: "ai-msg " + role }, h("div", { class: "bubble" }, body, note ? h("div", { class: "ai-note", text: note }) : null));
    log.appendChild(msg);
    log.scrollTop = log.scrollHeight;
  }

  function updateMeter() {
    var left = remaining(), q = quota();
    var t = "Осталось вопросов: " + left + " из " + LIMIT;
    if (q.start && left < LIMIT) t += " · лимит обновится через " + K.fmtLeft(resetIn());
    meter.textContent = t;
    meter.classList.toggle("warn", left <= 0);
  }

  async function ask(raw) {
    var text = K.clean(raw, 200);
    if (!text || busy) return;
    busy = true; send.disabled = true; input.value = "";
    add("user", text);
    var left = remaining();
    if (left <= 0) { add("bot", limitMessage()); updateMeter(); busy = false; send.disabled = false; return; }
    var res = await answer(text), cost = res.onTopic ? 1 : 2;
    if (left < cost) {
      add("bot", "Остался " + left + " вопрос, а вопрос не по теме стоит 2. Задайте вопрос о сервере или вернитесь через " + K.fmtLeft(resetIn()) + ".");
    } else {
      spend(cost);
      add("bot", res.text, res.onTopic ? "" : "Вопрос не по теме: списано 2 вопроса.");
    }
    updateMeter(); busy = false; send.disabled = false;
  }

  send.addEventListener("click", function () { ask(input.value); });
  input.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); ask(input.value); } });

  var chips = h("div", { class: "ai-chips" });
  ["Кто владельцы?", "Во что играют?", "Кто в команде?", "Как вступить?", "Где магазин?"].forEach(function (t) {
    chips.appendChild(h("button", { class: "chip small", type: "button", text: t, onclick: function () { ask(t); } }));
  });

  root.appendChild(h("h3", { text: "Спросите о сервере" }));
  root.appendChild(h("p", { class: "dim", text: "Помощник отвечает по данным сайта. Лимит: 10 вопросов за 5 часов, вопрос не по теме списывает 2." }));
  root.appendChild(chips);
  root.appendChild(log);
  root.appendChild(h("div", { class: "ai-input" }, input, send));
  root.appendChild(meter);
  root.appendChild(h("p", { class: "note", text: "Счётчик вопросов хранится в вашем браузере." }));

  add("bot", "Привет! Я расскажу о сервере Katorama: владельцы, команда, игры, рейтинг, магазин, партнёры и как вступить.");
  updateMeter();
  setInterval(updateMeter, 30000);
})();
