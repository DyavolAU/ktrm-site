/* Общие помощники. Весь HTML строится через createElement и textContent, поэтому чужой текст
   (ники, сообщения чата) никогда не превращается в код. */
(function () {
  "use strict";
  var K = window.KTRM = {
    cfg: window.KTRM_CONFIG,
    data: window.KTRM_DATA,
    state: { members: 533, online: null, top: null, tab: "home" }
  };

  K.$ = function (sel, root) { return (root || document).querySelector(sel); };
  K.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  function append(el, child) {
    if (child == null || child === false) return;
    if (Array.isArray(child)) { child.forEach(function (c) { append(el, c); }); return; }
    el.appendChild(child.nodeType ? child : document.createTextNode(String(child)));
  }

  /* h("div", {class: "x", text: "..."}, дети...) */
  K.h = function (tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v == null || v === false) return;
        if (k === "class") el.className = v;
        else if (k === "text") el.textContent = v;
        else if (k === "data") Object.keys(v).forEach(function (d) { el.dataset[d] = v[d]; });
        else if (k.slice(0, 2) === "on" && typeof v === "function") el.addEventListener(k.slice(2), v);
        else el.setAttribute(k, v === true ? "" : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  };

  K.clear = function (el) { while (el.firstChild) el.removeChild(el.firstChild); return el; };

  K.store = {
    get: function (key, fallback) {
      try { var raw = localStorage.getItem(key); return raw == null ? fallback : JSON.parse(raw); }
      catch (e) { return fallback; }
    },
    set: function (key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (e) { return false; }
    },
    del: function (key) { try { localStorage.removeItem(key); } catch (e) { /* ничего */ } }
  };

  /* Очистка чужого текста: управляющие символы и символы смены направления текста */
  K.clean = function (s, max) {
    return String(s == null ? "" : s)
      .replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "")
      .trim().slice(0, max || 64);
  };

  K.safeAvatar = function (url) {
    return typeof url === "string" && /^https:\/\/(cdn\.discordapp\.com|media\.discordapp\.net)\//.test(url) ? url : "";
  };

  K.fmt = function (n) { return Number(n).toLocaleString("ru-RU"); };

  K.fmtTime = function (sec) {
    sec = Math.max(0, Math.floor(sec));
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    function two(x) { return (x < 10 ? "0" : "") + x; }
    return h + ":" + two(m) + ":" + two(s);
  };

  K.fmtLeft = function (ms) {
    var m = Math.max(1, Math.ceil(ms / 60000)), h = Math.floor(m / 60);
    return h > 0 ? h + " ч " + (m % 60) + " мин" : m + " мин";
  };

  /* Плавное изменение числа */
  var shown = new WeakMap();
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  K.reduceMotion = !!reduce;
  K.setNum = function (el, target) {
    var from = shown.has(el) ? shown.get(el) : 0;
    shown.set(el, target);
    if (reduce || from === target) { el.textContent = K.fmt(target); return; }
    var start = performance.now(), dur = 800;
    (function tick(now) {
      var t = Math.min(1, (now - start) / dur);
      el.textContent = K.fmt(Math.round(from + (target - from) * (1 - Math.pow(1 - t, 3))));
      if (t < 1) requestAnimationFrame(tick);
    })(start);
  };

  /* Вызвать сразу и затем по таймеру; на скрытой вкладке браузера не работает */
  K.every = function (fn, ms) {
    fn();
    setInterval(function () { if (!document.hidden) fn(); }, ms);
  };

  /* Ссылки только https и только на известные хосты */
  K.linkify = function (text) {
    var out = [], re = /https:\/\/[A-Za-z0-9./+#_?=&%-]+/g, last = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > last) out.push(text.slice(last, m.index));
      out.push(K.h("a", { href: m[0], target: "_blank", rel: "noopener noreferrer", text: m[0] }));
      last = m.index + m[0].length;
    }
    if (last < text.length) out.push(text.slice(last));
    return out;
  };

  /* Сколько дней назад было (для стрелок и возраста сервера) */
  K.daysSince = function (isoDate) {
    var t = Date.parse(isoDate + "T00:00:00");
    return isNaN(t) ? Infinity : (Date.now() - t) / 86400000;
  };
})();
