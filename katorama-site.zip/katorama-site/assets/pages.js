/* Страницы сайта: вкладки, тема, живые данные Discord, рейтинг, команда, игры, участники, партнёры. */
(function () {
  "use strict";
  var K = window.KTRM, D = K.data, C = K.cfg, h = K.h, $ = K.$, $$ = K.$$;
  var TABS = ["home", "about", "top", "stats", "members", "games", "team", "collab", "shop", "arcade", "chat", "join"];
  var SPLASH = "https://cdn.discordapp.com/splashes/1523684690521886840/ad34ab00aa30d7250f731c79c13ee94d.jpg?size=512";
  var current = "home";

  /* ---------- тема ---------- */
  var themeBtn = $("#themeBtn");
  function applyTheme(t) {
    document.documentElement.setAttribute("data-theme", t);
    themeBtn.setAttribute("aria-label", t === "dark" ? "Включить светлую тему" : "Включить тёмную тему");
    themeBtn.setAttribute("title", t === "dark" ? "Светлая тема" : "Тёмная тема");
  }
  applyTheme(document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark");
  themeBtn.addEventListener("click", function () {
    var next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    applyTheme(next);
    try { localStorage.setItem("ktrm-theme", next); } catch (e) { /* ничего */ }
  });

  /* ---------- вкладки ---------- */
  var ind = $(".tab-ind");
  function moveInd(name) {
    var b = document.getElementById("t-" + name);
    if (!b || !ind) return;
    ind.style.width = b.offsetWidth + "px";
    ind.style.transform = "translateX(" + b.offsetLeft + "px)";
    var c = getComputedStyle(b).getPropertyValue("--c").trim();
    if (c) ind.style.backgroundColor = c;
    if (b.scrollIntoView) b.scrollIntoView({ block: "nearest", inline: "center", behavior: K.reduceMotion ? "auto" : "smooth" });
  }

  function show(name, push) {
    if (TABS.indexOf(name) === -1) name = "home";
    TABS.forEach(function (t) {
      document.getElementById(t).hidden = t !== name;
      var b = document.getElementById("t-" + t);
      b.setAttribute("aria-selected", String(t === name));
      b.tabIndex = t === name ? 0 : -1;
    });
    current = name; K.state.tab = name;
    var cur = document.getElementById(name);
    cur.classList.remove("enter"); void cur.offsetWidth; cur.classList.add("enter");
    moveInd(name);
    if (push && location.hash !== "#" + name) { try { history.pushState(null, "", "#" + name); } catch (e) { /* в песочнице адрес менять нельзя */ } }
    window.scrollTo(0, 0);
    document.dispatchEvent(new CustomEvent("ktrm:tab", { detail: name }));
  }
  K.show = show;

  $$("[data-tab]").forEach(function (b) { b.addEventListener("click", function () { show(b.dataset.tab, true); }); });
  document.addEventListener("click", function (e) {
    var go = e.target.closest && e.target.closest("[data-go]");
    if (go) show(go.dataset.go, true);
  });
  $(".logo").addEventListener("click", function (e) { e.preventDefault(); show("home", true); });
  $("#tabs").addEventListener("keydown", function (e) {
    if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
    var i = TABS.indexOf(current);
    var n = TABS[(i + (e.key === "ArrowRight" ? 1 : TABS.length - 1)) % TABS.length];
    show(n, true); document.getElementById("t-" + n).focus();
  });
  window.addEventListener("popstate", function () { show(location.hash.slice(1), false); });
  window.addEventListener("resize", function () { moveInd(current); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { moveInd(current); });

  /* ---------- ссылки на сервер ---------- */
  $$(".join-link").forEach(function (a) { a.href = D.inviteUrl; });
  $$("a[data-shop]").forEach(function (a) { a.href = C.shopUrl; });
  $$("[data-copy-invite]").forEach(function (b) {
    b.addEventListener("click", function () {
      var done = function () { var old = b.textContent; b.textContent = "Скопировано"; setTimeout(function () { b.textContent = old; }, 1600); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(D.inviteUrl).then(done, function () { /* нет доступа */ });
    });
  });

  /* ---------- число участников и онлайн ---------- */
  async function fetchInvite() {
    for (var i = 0; i < C.inviteCodes.length; i++) {
      try {
        var r = await fetch("https://discord.com/api/v10/invites/" + encodeURIComponent(C.inviteCodes[i]) + "?with_counts=true");
        if (r.ok) return await r.json();
      } catch (e) { /* пробуем следующий код */ }
    }
    return null;
  }

  async function updateCounts() {
    var d = await fetchInvite();
    if (!d) return;
    if (typeof d.approximate_member_count === "number") {
      K.state.members = d.approximate_member_count;
      $$("[data-members]").forEach(function (el) { K.setNum(el, d.approximate_member_count); });
      var note = $("#membersNote"); if (note) note.textContent = "(обновляется автоматически)";
    }
    if (typeof d.approximate_presence_count === "number") {
      K.state.online = d.approximate_presence_count;
      $("#onlineStat").hidden = false;
      $$("[data-online]").forEach(function (el) { K.setNum(el, d.approximate_presence_count); });
      var wrap = $("#stOnlineWrap"); if (wrap) wrap.hidden = false;
      if (K.state.members > 0) {
        var share = $("#stShare");
        if (share) { share.textContent = Math.round(d.approximate_presence_count / K.state.members * 100) + "%"; $("#stShareWrap").hidden = false; }
      }
    }
  }

  /* ---------- о сервере ---------- */
  function renderAbout() {
    $("#aboutText").appendChild(h("p", { text: "Katorama — это " + D.description.charAt(0).toLowerCase() + D.description.slice(1) }));
    $("#aboutText").appendChild(h("p", { text: "Главная игра сервера — Among Us, но в войсах так же часто играют в PEAK, R.E.P.O., CS2, Minecraft и другие игры. Заходить рады каждому." }));
    var img = $("#splash");
    img.src = SPLASH;
    img.addEventListener("error", function () { img.style.display = "none"; });
    var created = new Date(D.created + "T00:00:00");
    var rows = [
      ["Название", D.name],
      ["Участников", h("span", {}, h("span", { "data-members": "" , text: K.fmt(K.state.members) }), " ", h("span", { id: "membersNote", class: "dim", text: "(на момент создания сайта)" }))],
      ["Язык", D.language],
      ["Сервер создан", created.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" }) + " (дата определена по ID сервера)"],
      ["Основные игры", Object.keys(D.games).join(", ") + " и другие"],
      ["Владельцы", D.owners.join(", ")],
      ["Ссылка-приглашение", h("a", { href: D.inviteUrl, target: "_blank", rel: "noopener noreferrer", text: D.inviteUrl.replace("https://", "") })],
      ["Короткая ссылка", h("a", { href: D.shortInviteUrl, target: "_blank", rel: "noopener noreferrer", text: D.shortInviteUrl.replace("https://", "") })],
      ["Сайт из описания", h("a", { href: D.descriptionSite, target: "_blank", rel: "noopener noreferrer", text: D.descriptionSite.replace("https://", "").replace(/\/$/, "") })]
    ];
    var dl = $("#aboutFacts");
    rows.forEach(function (r) { dl.appendChild(h("div", { class: "fact" }, h("dt", { text: r[0] }), h("dd", {}, r[1]))); });
  }

  /* ---------- команда ---------- */
  function teamNames() {
    var set = {};
    D.owners.forEach(function (n) { set[n] = true; });
    D.groups.forEach(function (g) { g.members.forEach(function (m) { set[m.name] = true; }); });
    return Object.keys(set);
  }
  K.teamNames = teamNames;

  function renderTeam() {
    var owners = K.clear($("#owners"));
    D.owners.forEach(function (n, i) {
      owners.appendChild(h("div", { class: "owner", "data-c": i === 0 ? "red" : "cyan" },
        h("div", { class: "role", text: "Owner" }), h("div", { class: "name", text: n })));
    });
    var staff = K.clear($("#staff"));
    D.groups.forEach(function (g) {
      var ul = h("ul");
      g.members.forEach(function (m) {
        var recent = m.change && K.daysSince(m.date) < 10;   /* стрелка живёт 10 дней */
        ul.appendChild(h("li", {
          class: "member",
          "data-change": recent ? m.change : null,
          title: recent ? (m.change === "up" ? "Недавно повышен(а)" : "Недавно понижен(а)") : null
        }, h("i"), m.name));
      });
      staff.appendChild(h("section", { class: "group", "data-c": g.color }, h("h3", { text: g.title }), h("p", { class: "about", text: g.about }), ul));
    });
  }

  /* ---------- статистика ---------- */
  function renderStats() {
    var grid = K.clear($("#statGrid"));
    function card(color, big, label, extra) { var c = h("div", Object.assign({ class: "stat-card", "data-c": color }, extra || {}), big, h("div", { class: "lbl", text: label })); grid.appendChild(c); return c; }
    card("red", h("div", { class: "num", "data-members": "", text: K.fmt(K.state.members) }), "участников");
    card("lime", h("div", { class: "num", "data-online": "", text: "0" }), "сейчас онлайн", { id: "stOnlineWrap", hidden: true });
    card("pink", h("div", { class: "num", id: "stShare", text: "0%" }), "участников онлайн", { id: "stShareWrap", hidden: true });
    card("cyan", h("div", { class: "num", text: K.fmt(Math.max(0, Math.floor(K.daysSince(D.created)))) }), "дней с создания сервера");
    card("orange", h("div", { class: "num", text: String(teamNames().length) }), "человек в команде");

    var groups = [["Owner", D.owners.length]].concat(D.groups.map(function (g) { return [g.title, g.members.length]; }));
    var max = Math.max.apply(null, groups.map(function (g) { return g[1]; })) || 1;
    var bars = K.clear($("#roleBars"));
    groups.forEach(function (g) {
      var fill = h("span", { class: "bar-fill" });
      fill.style.width = (g[1] / max * 100) + "%";
      bars.appendChild(h("div", { class: "bar-row" }, h("span", { text: g[0] }), h("span", { class: "bar-track" }, fill), h("span", { class: "bar-num", text: String(g[1]) })));
    });
  }

  /* ---------- игры ---------- */
  var activeGame = "Among Us";
  var MEDALS = ["\uD83E\uDD47", "\uD83E\uDD48", "\uD83E\uDD49"];
  function renderGames() {
    var g = D.games[activeGame];
    var main = K.clear($("#gameMain"));
    main.setAttribute("data-c", g.color);
    main.appendChild(h("h3", { text: activeGame }));
    main.appendChild(h("p", { text: g.text }));
    main.classList.remove("pop"); void main.offsetWidth; main.classList.add("pop");

    var chips = K.clear($("#gameChips"));
    Object.keys(D.games).filter(function (n) { return n !== activeGame; }).forEach(function (n) {
      chips.appendChild(h("button", { type: "button", class: "chip", "data-c": D.games[n].color, text: n,
        onclick: function () { activeGame = n; renderGames(); } }));
    });
    chips.appendChild(h("span", { class: "chip more", text: "и другие игры" }));

    var top = K.clear($("#gameTop"));
    top.appendChild(h("h3", { text: "Чаще всего играют в " + activeGame }));
    var ol = h("ol");
    g.top.forEach(function (n, i) { ol.appendChild(h("li", {}, h("span", { class: "rank", text: MEDALS[i] }), h("span", { text: n }))); });
    top.appendChild(ol);
  }

  /* ---------- рейтинг (data/top.json, обновляется сам) ---------- */
  var lbActive = "points";
  function cleanTop(j) {
    if (!j || typeof j !== "object") return null;
    function list(arr, valKey) {
      if (!Array.isArray(arr)) return [];
      return arr.slice(0, 50).map(function (r) {
        if (!r || typeof r !== "object") return null;
        var name = K.clean(r.name, 48), v = Number(r[valKey]);
        if (!name || !isFinite(v) || v < 0) return null;
        var o = { name: name }; o[valKey] = v;
        if (valKey === "xp") { var lv = Number(r.level); o.level = isFinite(lv) && lv >= 0 ? Math.floor(lv) : 0; }
        return o;
      }).filter(Boolean);
    }
    var updated = Date.parse(j.updated);
    return { updated: isNaN(updated) ? null : updated, points: list(j.points, "xp"), voice: list(j.voice, "seconds") };
  }

  function renderTop() {
    var t = K.state.top;
    var tabs = K.clear($("#lbTabs"));
    [["points", "Очки Juniper"], ["voice", "Время в войсе"]].forEach(function (x) {
      tabs.appendChild(h("button", { type: "button", class: "lb-tab", role: "tab", "aria-selected": String(lbActive === x[0]), text: x[1],
        onclick: function () { lbActive = x[0]; renderTop(); } }));
    });
    var key = lbActive === "points" ? "xp" : "seconds";
    var rows = (t[lbActive] || []).slice().sort(function (a, b) { return b[key] - a[key]; }).slice(0, 10);
    var max = rows.length ? rows[0][key] || 1 : 1;
    var list = K.clear($("#lbList"));
    if (!rows.length) list.appendChild(h("li", { class: "lb-empty", text: "Рейтинг пока пуст." }));
    rows.forEach(function (r, i) {
      var fill = h("span", { class: "bar-fill" });
      fill.style.width = (r[key] / max * 100) + "%";
      var val = lbActive === "points" ? "ур. " + r.level + " · " + K.fmt(r.xp) + " опыта" : K.fmtTime(r.seconds);
      list.appendChild(h("li", {}, h("span", { class: "rank", text: MEDALS[i] || String(i + 1) }), h("span", { class: "nm", text: r.name }),
        h("span", { class: "bar-track" }, fill), h("span", { class: "val", text: val })));
    });
    var meta = $("#lbMeta");
    if (t.updated) {
      var stale = Date.now() - t.updated > 86400000;
      meta.textContent = "Обновлено: " + new Date(t.updated).toLocaleString("ru-RU", { dateStyle: "long", timeStyle: "short" }) +
        (stale ? ". Данные не обновлялись больше суток." : "");
      meta.classList.toggle("warn", stale);
    }
  }

  async function loadTop() {
    try {
      var r = await fetch("data/top.json?t=" + Math.floor(Date.now() / 30000), { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      var t = cleanTop(await r.json());
      if (t && (t.points.length || t.voice.length)) { K.state.top = t; renderTop(); }
    } catch (e) { /* остаётся прежний или запасной рейтинг */ }
  }

  /* ---------- участники онлайн (виджет Discord, до 100) ---------- */
  var memData = [], memMode = "", memErr = "";
  var STATUSES = ["online", "idle", "dnd"];
  function cleanMember(m) {
    if (!m || typeof m !== "object") return null;
    var name = K.clean(m.username, 64);
    if (!name) return null;
    return { name: name, avatar: K.safeAvatar(m.avatar_url), status: STATUSES.indexOf(m.status) !== -1 ? m.status : "" };
  }

  async function loadMembers() {
    try {
      var r = await fetch("https://discord.com/api/guilds/" + encodeURIComponent(C.guildId) + "/widget.json");
      if (r.ok) {
        var w = await r.json();
        memData = (Array.isArray(w.members) ? w.members : []).slice(0, 100).map(cleanMember).filter(Boolean);
        memMode = "online"; memErr = "";
      } else {
        memErr = "Discord ответил кодом " + r.status;
        try { var j = await r.json(); if (j && j.message) memErr += ", " + K.clean(j.message, 80); } catch (e) { /* без тела */ }
      }
    } catch (e) { memErr = "запрос не прошёл"; }
    renderMembers();
  }

  function renderMembers() {
    var q = $("#memSearch").value.trim().toLowerCase();
    var rows = memData.filter(function (m) { return m.name.toLowerCase().indexOf(q) !== -1; });
    $("#memCount").textContent = K.fmt(memData.length);
    $("#memLabel").textContent = "участников онлайн";
    var list = K.clear($("#memList"));
    rows.forEach(function (m) {
      var avatar;
      if (m.avatar) { avatar = h("img", { src: m.avatar, alt: "", loading: "lazy", referrerpolicy: "no-referrer" }); avatar.addEventListener("error", function () { avatar.style.visibility = "hidden"; }); }
      else avatar = h("span", { class: "av" });
      list.appendChild(h("li", {}, avatar, h("span", { class: "nm", text: m.name }), m.status ? h("span", { class: "st " + m.status, title: m.status }) : null));
    });
    var note = $("#memNote");
    if (!memMode) note.textContent = "Не удалось получить список участников" + (memErr ? " (" + memErr + ")" : "") + ". Владельцу сервера нужно включить виджет: Настройки сервера, Виджет.";
    else note.textContent = "Показаны участники онлайн, до 100 человек: так работает виджет Discord.";
    $("#memUpdated").textContent = memMode ? "обновлено " + new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }) : "";
  }

  /* ---------- партнёры ---------- */
  function renderCollab() {
    var grid = K.clear($("#collabGrid"));
    D.partners.forEach(function (p) {
      grid.appendChild(h("a", { class: "collab-card", "data-c": p.color, href: p.url, target: "_blank", rel: "noopener noreferrer" },
        h("span", {}, h("span", { class: "collab-name", text: p.name }), h("br"), h("span", { class: "collab-kind", text: p.kind })),
        h("img", { src: p.img, alt: "Аватар: " + p.name, loading: "lazy" }),
        h("span", { class: "collab-go", text: "Перейти →" })));
    });
  }

  /* ---------- вступление ---------- */
  function renderJoin() {
    var links = K.clear($("#joinLinks"));
    [D.inviteUrl, D.shortInviteUrl].forEach(function (u) {
      links.appendChild(h("a", { href: u, target: "_blank", rel: "noopener noreferrer", text: u.replace("https://", "") }));
    });
  }

  /* ---------- запуск ---------- */
  K.state.top = {
    updated: Date.parse(D.topFallback.updated),
    points: D.topFallback.points, voice: D.topFallback.voice
  };
  renderAbout(); renderTeam(); renderStats(); renderGames(); renderTop(); renderCollab(); renderJoin(); renderMembers();
  $("#memSearch").addEventListener("input", renderMembers);

  var back = K.auth.handleReturn();
  show(back || location.hash.slice(1), false);
  K.auth.init();

  K.every(updateCounts, C.refreshMs);
  K.every(loadMembers, C.refreshMs);
  K.every(loadTop, C.topRefreshMs);

  /* Рейтинг: кнопка на публичную страницу Juniper */
  if (/^https:\/\//.test(C.juniperRankingUrl || "")) {
    var link = $("#lbLink"); link.href = C.juniperRankingUrl; link.hidden = false;
  }
})();
