/* Общий чат: доступен после входа через Discord. Сообщения хранятся в Supabase (таблица messages). */
(function () {
  "use strict";
  var K = window.KTRM, h = K.h;
  var root = K.$("#chatRoot");
  if (!root) return;

  var MAX = 500, FIELDS = "id,user_id,name,avatar,body,created_at";
  var lastId = 0, sending = false, lastSent = 0;

  var authBox = h("div", { class: "auth-box" });
  var status = h("p", { class: "note", role: "status" });
  var log = h("div", { class: "chat-log", role: "log", "aria-live": "polite" });
  var input = h("input", { type: "text", maxlength: String(MAX), placeholder: "Сообщение…", "aria-label": "Сообщение", autocomplete: "off" });
  var sendBtn = h("button", { class: "btn small", type: "button", text: "Отправить" });
  var composer = h("div", { class: "chat-input" }, input, sendBtn);
  root.appendChild(authBox); root.appendChild(status); root.appendChild(log); root.appendChild(composer);
  K.auth.bar(authBox, "chat");

  function draw() {
    var on = K.auth.enabled && !!K.auth.user;
    log.hidden = !on; composer.hidden = !on;
    if (!K.auth.enabled) status.textContent = "Общий чат пока недоступен: не подключена база (Supabase), см. README.";
    else if (!K.auth.user) status.textContent = "Войдите через Discord, чтобы читать чат и писать сообщения.";
    else status.textContent = "";
  }

  function addMessage(m) {
    var name = K.clean(m.name, 64) || "Участник", body = K.clean(m.body, MAX);
    if (!body) return;
    var avatar = K.safeAvatar(m.avatar), t = new Date(m.created_at);
    var mine = K.auth.user && m.user_id === K.auth.user.id;
    var img;
    if (avatar) { img = h("img", { src: avatar, alt: "", width: "32", height: "32", loading: "lazy", referrerpolicy: "no-referrer" }); img.addEventListener("error", function () { img.style.visibility = "hidden"; }); }
    else img = h("span", { class: "av" });
    log.appendChild(h("div", { class: "chat-msg" + (mine ? " mine" : "") }, img,
      h("div", {}, h("div", { class: "chat-head" }, h("strong", { text: name }),
        h("span", { class: "dim", text: isNaN(t) ? "" : t.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }) })),
        h("div", { class: "chat-body", text: body }))));
    while (log.children.length > 200) log.removeChild(log.firstChild);
  }

  async function poll(first) {
    if (!K.auth.enabled || !K.auth.user || K.state.tab !== "chat" || document.hidden) return;
    var fresh = first || !lastId;
    var path = "/rest/v1/messages?select=" + FIELDS + (fresh ? "&order=id.desc&limit=50" : "&order=id.asc&id=gt." + lastId);
    var res = await K.auth.request("GET", path);
    if (!res.ok) { status.textContent = "Не удалось загрузить сообщения. Проверьте, что в Supabase создана таблица messages (см. README)."; return; }
    status.textContent = "";
    var rows = Array.isArray(res.data) ? res.data : [];
    if (fresh) { rows.reverse(); K.clear(log); }
    var atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 80;
    rows.forEach(function (m) { addMessage(m); if (Number(m.id) > lastId) lastId = Number(m.id); });
    if (fresh || atBottom) log.scrollTop = log.scrollHeight;
  }

  async function post() {
    var text = K.clean(input.value, MAX);
    if (!text || sending) return;
    if (Date.now() - lastSent < 2000) { status.textContent = "Не так быстро: одно сообщение раз в 2 секунды."; return; }
    sending = true; sendBtn.disabled = true;
    var res = await K.auth.request("POST", "/rest/v1/messages", { body: text }, { Prefer: "return=minimal" });
    if (res.ok) { input.value = ""; lastSent = Date.now(); status.textContent = ""; await poll(false); }
    else status.textContent = "Не удалось отправить сообщение: слишком часто или нет доступа.";
    sending = false; sendBtn.disabled = false;
  }

  sendBtn.addEventListener("click", post);
  input.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); post(); } });
  document.addEventListener("ktrm:tab", function (e) { if (e.detail === "chat") poll(true); });
  K.auth.onChange(function () { lastId = 0; K.clear(log); draw(); poll(true); });
  setInterval(function () { poll(false); }, 3000);
  draw();
})();
