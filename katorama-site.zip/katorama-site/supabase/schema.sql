-- Katorama: база для входа через Discord, общего чата и общего кошелька.
-- Вставьте целиком в Supabase: SQL Editor -> New query -> Run.
-- Все таблицы закрыты правилами доступа (RLS): без них анонимный ключ в коде сайта был бы опасен.

-- ---------- Профили (создаются автоматически при первом входе) ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  discord_id text unique,
  display_name text not null default 'Участник',
  avatar_url text,
  is_admin boolean not null default false,   -- выдаётся вручную в панели Supabase
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using (true);

-- ---------- Кошельки и журнал начислений ----------
create table if not exists public.wallets (
  user_id uuid primary key references auth.users (id) on delete cascade,
  coins integer not null default 0 check (coins >= 0),
  updated_at timestamptz not null default now()
);
alter table public.wallets enable row level security;
drop policy if exists wallets_read_own on public.wallets;
create policy wallets_read_own on public.wallets for select to authenticated using (auth.uid() = user_id);
-- Политик на запись нет: изменить кошелёк можно только функцией earn_coins ниже.

create table if not exists public.ledger (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  delta integer not null,
  reason text not null,
  created_at timestamptz not null default now()
);
create index if not exists ledger_user_time on public.ledger (user_id, created_at desc);
alter table public.ledger enable row level security;
drop policy if exists ledger_read_own on public.ledger;
create policy ledger_read_own on public.ledger for select to authenticated using (auth.uid() = user_id);

-- ---------- Создание профиля и кошелька при регистрации ----------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, discord_id, display_name, avatar_url)
  values (
    new.id,
    new.raw_user_meta_data ->> 'provider_id',
    left(coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', 'Участник'), 64),
    new.raw_user_meta_data ->> 'avatar_url'
  ) on conflict (id) do nothing;
  insert into public.wallets (user_id, coins) values (new.id, 0) on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Начисление монет за мини-игру (всё считает сервер) ----------
-- Победа (15+ очков) = 50 монет, иначе 5. Не чаще раза в 25 секунд и не больше 200 монет в сутки.
create or replace function public.earn_coins(p_game text, p_score integer) returns json
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  v_last timestamptz;
  v_today integer;
  v_reward integer;
  v_coins integer;
begin
  if uid is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  if p_game is distinct from 'impostor' then raise exception 'unknown game'; end if;
  if p_score is null or p_score < 0 or p_score > 40 then raise exception 'bad score'; end if;

  insert into public.wallets (user_id, coins) values (uid, 0) on conflict do nothing;

  select max(created_at) into v_last from public.ledger where user_id = uid and reason like 'game:%';
  if v_last is not null and now() - v_last < interval '25 seconds' then
    select coins into v_coins from public.wallets where user_id = uid;
    return json_build_object('earned', 0, 'coins', v_coins, 'reason', 'cooldown');
  end if;

  select coalesce(sum(delta), 0) into v_today from public.ledger
   where user_id = uid and reason like 'game:%' and created_at >= date_trunc('day', now() at time zone 'utc');

  v_reward := case when p_score >= 15 then 50 else 5 end;
  v_reward := least(v_reward, greatest(0, 200 - v_today));

  update public.wallets set coins = coins + v_reward, updated_at = now() where user_id = uid returning coins into v_coins;
  insert into public.ledger (user_id, delta, reason) values (uid, v_reward, 'game:impostor:' || p_score);
  return json_build_object('earned', v_reward, 'coins', v_coins, 'reason', case when p_score >= 15 then 'win' else 'lose' end);
end $$;
revoke all on function public.earn_coins(text, integer) from public;
grant execute on function public.earn_coins(text, integer) to authenticated;

-- ---------- Общий чат ----------
create table if not exists public.messages (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  name text not null default '',
  avatar text,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz not null default now()
);
alter table public.messages enable row level security;
drop policy if exists messages_read on public.messages;
create policy messages_read on public.messages for select to authenticated using (true);
drop policy if exists messages_insert on public.messages;
create policy messages_insert on public.messages for insert to authenticated with check (user_id = auth.uid());
drop policy if exists messages_delete_admin on public.messages;
create policy messages_delete_admin on public.messages for delete to authenticated
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin));

-- Имя и аватар подставляет сервер из профиля (подделать чужое имя нельзя), не чаще 1 сообщения в 2 секунды.
create or replace function public.messages_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  p public.profiles;
  v_last timestamptz;
begin
  select * into p from public.profiles where id = new.user_id;
  if p.id is null then raise exception 'no profile'; end if;
  select max(created_at) into v_last from public.messages where user_id = new.user_id;
  if v_last is not null and now() - v_last < interval '2 seconds' then raise exception 'too fast'; end if;
  new.name := p.display_name;
  new.avatar := p.avatar_url;
  new.body := btrim(new.body);
  return new;
end $$;
drop trigger if exists messages_bi on public.messages;
create trigger messages_bi before insert on public.messages for each row execute function public.messages_before_insert();

-- Необязательно: хранить только последние 7 дней сообщений (нужно расширение pg_cron):
-- select cron.schedule('clean-chat', '0 4 * * *', $$delete from public.messages where created_at < now() - interval '7 days'$$);
